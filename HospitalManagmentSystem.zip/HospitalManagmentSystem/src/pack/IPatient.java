package pack;

public interface IPatient {
	final String Type="PATIENT";
	public abstract Patient input(Patient ob);
	public abstract void  display(Patient ob);
}
