package pack;

import java.util.ArrayList;
import java.util.Scanner;

public class MainClass {

	static ArrayList<String> doc=new ArrayList<String>();
	static ArrayList<String> stf=new ArrayList<String>();
	static ArrayList<String> pat=new ArrayList<String>();
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int sel,i=0;
		char ch;
		do{
		System.out.println("!!!Welcome to Hospital Management System!!!");
		System.out.println("Please select any one option below !\n1. Add a Doctor\n2. Add a Staff\n3. Add a Patient\n4. List Names of patients");
		System.out.println("5. List Names of Doctors\n6. List Names of Staffs\n7. Bill Patient");
		sel=sc.nextInt();
		sc.nextLine();
		switch(sel){
			case 1:
				Doctor d=new Doctor();
				d=d.input(d);
				doc.add(d.name);
				System.out.println("The doctor details were saved successfully");
				break;
			case 2:
				Staff d1=new Staff();
				d1=d1.input1(d1);
				stf.add(d1.name);
				System.out.println("The Staff details were saved successfully");
				break;
			case 3:
				Patient p=new Patient();
				p=p.input(p);
				pat.add(p.name);
				System.out.println("The Patient details were saved successfully");
				break;
			case 4:
				i=1;
				for(String n: pat){
					System.out.println(i+". "+n);
					i++;
				}
				break;
			case 5:
				i=1;
				for(String n: doc){
					System.out.println(i+". "+n);
					i++;
				}
				break;
			case 6:
				i=1;
				for(String n: stf){
					System.out.println(i+". "+n);
					i++;
				}
				break;
			case 7:
				System.out.println("----------------------------------------------------");
				System.out.println("The Final Amount to be Paid is : " + ExpensesBill.display(pat, doc));
				System.out.println("----------------------------------------------------");
				break;
			default:
				System.out.println("Invalid Choice");
				break;
		}
		System.out.println("Please let us know if you wanna do more operation(y/n)");
		ch=sc.nextLine().charAt(0);
		
		}while(ch=='y');
		System.out.println("Thanks Exiting");
		sc.close();
	}

}
