package pack;
import java.util.ArrayList;
import java.util.Scanner;

public class ExpensesBill {
	static Scanner sc;
	
	static double display(ArrayList<String> pat, ArrayList<String> doc){
		sc=new Scanner(System.in);
		int i=1, sel=0, days;
		double med, bed, other, amt=0;
		System.out.println("Below are the list of patients, select one :");
		for(String n : pat){
			System.out.println(i+". "+ n );
			i++;
		}
		sel=sc.nextInt();
		if(sel<=pat.size()){
			System.out.println("Patient Name : "+pat.get(sel-1));
			System.out.println("Below are the list of doctors, select one :");
			i=1;
			for(String n: doc){
				System.out.println(i+". "+n);
				i++;
			}
			sel=sc.nextInt();
			if(sel<=doc.size()){
				System.out.println("Doctor Name : "+pat.get(sel-1));
				System.out.println("Base Consultation fees is : 200");
				System.out.println("Please enter per bed charge : ");
				bed=sc.nextDouble();
				System.out.println("Please enter number of days occupied the bed : ");
				days=sc.nextInt();
				System.out.println("Please enter Medicine costs : ");
				med=sc.nextDouble();
				System.out.println("Please enter other charges : ");
				other=sc.nextDouble();
				amt=200+(bed*days)+med+other;
			}
		}
		return amt;
	}
	
}
