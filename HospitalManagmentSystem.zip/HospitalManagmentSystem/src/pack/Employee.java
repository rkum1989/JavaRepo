package pack;

public abstract class Employee {
	String name, gender, address, designation;
	long phno;
	int age, id;
	double salary;
	public abstract void display(Object ob);
	public abstract Doctor input(Doctor ob);
	public abstract Staff input1(Staff ob);
}
