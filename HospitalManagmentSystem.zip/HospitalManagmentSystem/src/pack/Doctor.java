package pack;

import java.util.Scanner;

public class Doctor extends Employee{
	String skill;
	int fees;
	Scanner sc;
	
	public Doctor() {
		sc=new Scanner(System.in);
	}

	@Override
	public void display(Object d) {
		Doctor ob=(Doctor) d;
		System.out.println("DESIGNATION : "+ob.designation);
		System.out.println("Name : "+ob.name);
		System.out.println("Gender : "+ob.gender);
		System.out.println("Age : "+ob.age);
		System.out.println("Address : "+ob.address);
		System.out.println("Phone Number : "+ob.phno);
		System.out.println("Salary : "+ob.salary);
		System.out.println("Fees per consultation : "+ob.fees);
		System.out.println("Skills : "+ob.skill);
	}


	@Override
	public Doctor input(Doctor ob) {
		System.out.print("DESIGNATION : ");
		ob.designation=sc.nextLine();
		System.out.print("Enter Doctor's Name : ");
		ob.name=sc.nextLine();
		System.out.print("Gender : ");
		ob.gender=sc.nextLine();
		System.out.print("Age : ");
		ob.age=sc.nextInt();
		sc.nextLine();
		System.out.print("Address : ");
		ob.address=sc.nextLine();
		System.out.print("Phone Number : ");
		ob.phno=sc.nextLong();
		System.out.print("Salary : ");
		ob.salary=sc.nextDouble();
		System.out.print("Fees per consultation : ");
		ob.fees=sc.nextInt();
		sc.nextLine();
		System.out.print("Skills :");
		ob.skill=sc.nextLine();
		return ob;
	}

	@Override
	public Staff input1(Staff ob) {
		// TODO Auto-generated method stub
		return null;
	}	
}
