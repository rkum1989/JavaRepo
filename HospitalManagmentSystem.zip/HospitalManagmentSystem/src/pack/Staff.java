package pack;

import java.util.Scanner;

public class Staff extends Employee {
	Scanner sc;
	
	public Staff() {
		sc=new Scanner(System.in);
	}

	@Override
	public void display(Object d) {
		Staff ob=(Staff) d;
		System.out.println("DESIGNATION :"+ob.designation);
		System.out.println("Name :"+ob.name);
		System.out.println("Gender :"+ob.gender);
		System.out.println("Age :"+ob.age);
		System.out.println("Address :"+ob.address);
		System.out.println("Phone Number :"+ob.phno);
		System.out.println("Salary :"+ob.salary);
	}

	@Override
	public Doctor input(Doctor ob) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Staff input1(Staff ob) {
		System.out.print("Enter Staff's DESIGNATION :");
		ob.designation=sc.nextLine();
		System.out.print("Name :");
		ob.name=sc.nextLine();
		System.out.print("Gender :");
		ob.gender=sc.nextLine();
		System.out.print("Age :");
		ob.age=sc.nextInt();
		sc.nextLine();
		System.out.print("Address :");
		ob.address=sc.nextLine();
		System.out.print("Phone Number :");
		ob.phno=sc.nextLong();
		System.out.print("Salary :");
		ob.salary=sc.nextDouble();
		return ob;
	}
}
