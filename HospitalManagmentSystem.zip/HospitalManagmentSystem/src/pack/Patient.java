package pack;

import java.util.Scanner;

public class Patient implements IPatient {
	String name, address, gender, reference, relation, disease, descriptionSymptoms;
	int age, weight;
	double height;
	long phno, refrencePhNo;
	Scanner sc;
	
	public Patient() {
		sc=new Scanner(System.in);
	}


	@Override
	public Patient input(Patient ob) {
		System.out.println("!!! Please enter the patient details as asked below !!!");
		System.out.print("Enter The Name Of Patient : ");
		ob.name=sc.nextLine();
		System.out.print("Enter Gender : ");
		ob.gender=sc.nextLine();
		System.out.print("Enter age : ");
		ob.age=sc.nextInt();
		sc.nextLine();
		System.out.print("Enter Patient Address : ");
		ob.address=sc.nextLine();
		System.out.print("Enter phone number of patient : ");
		ob.phno=sc.nextLong();
		sc.nextLine();
		System.out.print("Enter Referance Person/Care taker : ");
		ob.reference=sc.nextLine();
		System.out.print("Enter Relation between the patient and the reference : ");
		ob.relation=sc.nextLine();
		System.out.print("Enter phone number of referance : ");
		ob.refrencePhNo=sc.nextLong();
		System.out.print("Enter Weight of patient : ");
		ob.weight=sc.nextInt();
		System.out.print("Enter Height of patient : ");
		ob.height=sc.nextDouble();
		sc.nextLine();
		System.out.print("Enter Disease to be treated if known else put N/A: ");
		ob.disease=sc.nextLine();
		System.out.print("Enter Symptoms and inputs from patient : ");
		ob.descriptionSymptoms=sc.nextLine();
		return ob;
	}


	@Override
	public void display(Patient ob) {
		System.out.println("!!! Please enter the patient details as asked below !!!");
		System.out.print("Name Of Patient : "+ob.name);
		System.out.print("Gender : "+ob.gender);
		System.out.print("Age : "+ob.age);
		System.out.print("Patient Address : "+ob.address);
		System.out.print("Phone number of patient : "+ob.phno);
		System.out.print("Referance Person/Care taker : "+ob.reference);
		System.out.print("Relation between the patient and the reference : "+ob.relation);
		System.out.print("Phone number of referance : "+ob.refrencePhNo);
		System.out.print("Weight of patient : "+ob.weight);
		System.out.print("Height of patient : "+ob.height);
		System.out.print("Disease to be treated : "+ob.disease);
		System.out.print("Symptoms and inputs from patient : "+ob.descriptionSymptoms);
	}
}
